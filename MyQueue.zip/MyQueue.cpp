﻿#include <iostream>

#include "OBJECT_CLASS_H.h"//перегрузка операторов >>, <<, = осуществлена в хедере

using namespace std;

template<typename T>
class MyQueue {//шаблонный класс очередь
	int SIZE;//максимальный размер очереди
	int size;//текущий размер
	T* item;
public:
	MyQueue();

	~MyQueue();

	void push(Animal new_object);

	T pop();

	T peek();

	int get_size();
};

template<typename T>
MyQueue<T>::MyQueue() {
	cout << "Введите размер очереди: " << endl;
	cin >> SIZE;
	size = 0;
	item = new T[SIZE];
}

template<typename T>
MyQueue<T>::~MyQueue() {
	delete[] item;
}

template<typename T>
int MyQueue<T>::get_size() {
	return size;
}

template<typename T>
void MyQueue<T>::push(Animal new_object) {
	if (size == SIZE) {
		cerr << "Queue is full!" << endl;
	}
	else {
		item[size] = new_object;
		size++;
	}
}

template<typename T>
T MyQueue<T>::pop() {
	if (size == 0) {
		cerr << "Queue is empty!" << endl;
		T a;
		return a;
	}
	else {
		T a = item[0];
		for (int i = 0; i < size - 1; i++) {
			item[i] = item[i + 1];
		}
		size--;
		return a;
	}
}

template<typename T>
T MyQueue<T>::peek() {
	if (size == 0) {
		cerr << "Queue is empty!" << endl;
		T a;
		return a;
	}
	else {
		return item[0];
	}
}

int main() {
	setlocale(LC_ALL, "rus");
	Animal animal, chosen_animal;
	int n = 5;
	MyQueue<Animal> queue;

	while (n != 0) {
		cout << "Чтобы добавить элемент в очередь, введите 1" << endl;
		cout << "Чтобы взять первый элемент очереди, введите 2" << endl;
		cout << "Чтобы посмотреть первый элемент очереди (не удаляя его из очереди), введите 3" << endl;
		cout << "Чтобы посмотреть количество элементов в очереди, введите 4" << endl;
		cout << "Чтобы выйти, введите 0" << endl << endl;
		cin >> n;
		while (cin.fail()) {//проверка корректности ввода
			cout << "Неправильное значение, попробуйте еще раз" << endl << endl;
			cin.clear();
			cin.ignore(32767, '\n');
			cin >> n;
		}
		cout << endl << endl;
		switch (n) {
		case 1:
			cout << "Введите элемент: " << endl;
			cin >> animal;
			queue.push(animal);//заталкивание элемента в очередь
			cout << endl << endl;
			break;
		case 2:
			chosen_animal = queue.pop();//вытаскивание первого элемента и присвоение переменной для дальнейшего использования
			cout << chosen_animal << endl << endl;//вывод элемента на экран
			break;
		case 3:
			cout << queue.peek() << endl << endl;//просмотр первого элемента
			break;
		case 4:
			cout << queue.get_size() << endl << endl;//текущий размер очереди
			break;
		case 0:
			break;
		default:
			cout << "Неправильное значение, попробуйте еще раз" << endl << endl;
			break;
		}
	}
}