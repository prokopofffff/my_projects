﻿#ifndef OBJECT_CLASS_H

#define OBJECT_CLASS_H

#include <string>

using namespace std;

class Animal {//создание класса Animal
	//поля класса:
	string name;
	int count_limb;
	int count_chrom;
	int weight;
	int habitat;//1-наземно-воздушная, 2-водная, 3-почвенная, 4-другое
public:
	Animal();//конструктор умолчания
	~Animal();//деструктор

	friend istream& operator >> (istream& in, Animal& animal);//перегрузка оператора >>
	friend ostream& operator << (ostream& out, const Animal& animal);//перегрузка оператора <<

	Animal& operator = (const Animal& animal) {//перегрузка оператора =
		name = animal.name;
		count_limb = animal.count_limb;
		count_chrom = animal.count_chrom;
		weight = animal.weight;
		habitat = animal.habitat;

		return *this;
	}
};

Animal::Animal() :name(), count_limb(0), count_chrom(0), weight(0), habitat(0) {//конструктор умолчания
}

Animal::~Animal() {//деструктор
}

istream& operator >> (istream& in, Animal& animal) {
	cout << "Введите название животного: " << endl;
	while (!(in >> animal.name)) {//проверка корректности ввода
		cout << "Неправильное значение, введите еще раз: " << endl;
	}

	cout << "Введите количество конечностей: " << endl;
	in >> animal.count_limb;
	while ((animal.count_limb <= 0) or (animal.count_limb % 2 == 1) or (animal.count_limb > 750) or in.fail()) {//проверка корректности ввода
		cout << "Неправильное значение, введите еще раз: " << endl;
		in.clear();
		in.ignore(32767, '\n');
		in >> animal.count_limb;
	}

	cout << "Введите количество хромосом: " << endl;
	in >> animal.count_chrom;
	while ((animal.count_chrom <= 0) or (animal.count_chrom % 2 == 1) or in.fail()) {//проверка корректности ввода
		cout << "Неправильное значение, введите еще раз: " << endl;
		in.clear();
		in.ignore(32767, '\n');
		in >> animal.count_chrom;
	}

	cout << "Введите вес: " << endl;
	in >> animal.weight;
	while (animal.weight <= 0 or in.fail()) {//проверка корректности ввода
		cout << "Неправильное значение, введите еще раз: " << endl;
		in.clear();
		in.ignore(32767, '\n');
		in >> animal.weight;
	}

	cout << "Введите среду обитания: " << endl << "1 - наземно-воздушная" << endl << "2 - водная" << endl << "3 - почвенная" << endl << "4 - другое" << endl;
	in >> animal.habitat;
	while ((animal.habitat != 1) and (animal.habitat != 2) and (animal.habitat != 3) and (animal.habitat != 4) or in.fail()) {//проверка корректности ввода
		cout << "Неправильное значение, введите еще раз: " << endl;
		in.clear();
		in.ignore(32767, '\n');
		in >> animal.habitat;
	}

	return in;
}

ostream& operator <<(ostream& out, const Animal& animal) {
	out << "Название: " << animal.name << endl;
	out << "Количество конечностей: " << animal.count_limb << endl;
	out << "Количество хромосом: " << animal.count_chrom << endl;
	out << "Вес: " << animal.weight << endl;
	if (animal.habitat == 1) {
		out << "Среда обитания: наземно-воздушная" << endl;
	}
	else if (animal.habitat == 2) {
		out << "Среда обитания: водная" << endl;
	}
	else if (animal.habitat == 3) {
		out << "Среда обитания: почвенная" << endl;
	}
	else if (animal.habitat == 4) {
		out << "Среда обитания: другое" <<  endl; 
	}

	return out;
}

#endif